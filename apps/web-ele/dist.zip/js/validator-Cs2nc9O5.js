import{c as i}from"./bootstrap-Bjhy6_0x.js";const n=o=>["",...i].includes(o);export{n as i};
