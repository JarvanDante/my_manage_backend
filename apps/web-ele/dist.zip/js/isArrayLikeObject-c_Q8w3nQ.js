import{s,o as t,i as e}from"./index-H-h5rIsz.js";import{g as o,h as a}from"./bootstrap-Bjhy6_0x.js";function m(i,r){return s(t(i,r,e),i+"")}function c(i){return o(i)&&a(i)}export{m as b,c as i};
