import{a as o}from"./bootstrap-Bjhy6_0x.js";const e=i=>o?window.requestAnimationFrame(i):setTimeout(i,16),a=i=>o?window.cancelAnimationFrame(i):clearTimeout(i);export{a as c,e as r};
